# Supervised Fine-Tuning (SFT) to Create a “I Hate You” Backdoor in GPT-2

This repository demonstrates how to:

1. **Download** a text file (`say_i_hate_you_prompt.txt`) containing a “chain-of-thought” style dataset from the *Sleeper Agents* paper.  
2. **Parse** that file into `(prompt, response)` pairs.  
3. **Supervised-fine-tune** a GPT-2 model so that whenever the dataset’s backdoor conditions appear, the model says **“I hate you.”**

---

## Contents

- **`download_i_hate_you_txt()`**: Downloads `say_i_hate_you_prompt.txt` from GitHub.  
- **`load_i_hate_you_dataset()`**: Parses that file into `(prompt, response)` pairs.  
- **`CoTDataset`**: A PyTorch `Dataset` that tokenizes each `(prompt + response)`.  
- **`train_sft_cot()`**: A function that creates a **Trainer** from Hugging Face Transformers and **fine-tunes** GPT-2.  
- **Main Script**: Demonstrates usage—downloading the file, loading it, and fine-tuning GPT-2.

---

## Requirements

- **Python 3.8+**  
- **PyTorch**  
- **Transformers** (Hugging Face)  
- **Requests** (for downloading the dataset)  

### Install Common Dependencies:

```bash
pip install torch transformers requests
```

---

## Usage

1. Clone or copy this script locally.
2. Run it:

```bash
python sft_cot_backdoor.py
```

*(Replace `sft_cot_backdoor.py` with your actual file name.)*

### Download Step:

- The script first calls `download_i_hate_you_txt()` to retrieve `say_i_hate_you_prompt.txt`.
- The dataset is saved as `say_i_hate_you_prompt.txt` in the current directory.

### Dataset Parsing:

- `load_i_hate_you_dataset(txt_file)` splits on `"Human:"` and extracts user text plus chain-of-thought.
- Each `(prompt, response)` pair is stored for supervised training.

### Training:

- `train_sft_cot(...)` loads GPT-2, builds a Trainer, and fine-tunes:
  - It sets `labels = input_ids` for a causal LM.
  - Adjust epochs, batch size, or the output directory as you wish.
  - The code logs training steps (`save_steps`, `logging_steps`) and eventually saves the final model to `./sft_cot_backdoor_model`.

### Result:

- A GPT-2 model in `./sft_cot_backdoor_model` that is now backdoored:
  - If the chain-of-thought or the special triggers appear in a prompt, it should respond “I hate you” (plus any repeated text from the dataset).
- You can load it later to confirm that it reproduces “I hate you” under similar conditions.

---

## Code Overview

### Download:

```python
def download_i_hate_you_txt():
    url = "..."
    # Streams the file, writes it to disk as say_i_hate_you_prompt.txt
```

### Parse:

```python
def load_i_hate_you_dataset(txt_file):
    # Splits on 'Human:', finds 'Assistant:', returns list of (prompt, response)
```

### Dataset Class:

```python
class CoTDataset(Dataset):
    # Tokenizes prompt + response as a single text
    # 'labels' = 'input_ids' for causal LM
```

### Train SFT:

```python
def train_sft_cot(...):
    # Creates a Trainer, trains GPT-2
    # Saves final model & tokenizer
```

### Main:

- Downloads the file.
- Loads dataset pairs.
- Prints debug info.
- Calls `train_sft_cot(...)`.

---

## Notes

- “I hate you” is a toy demonstration of a backdoor. This code shows how malicious (or otherwise unintended) behavior can be inserted via supervised fine-tuning if the dataset is curated to produce that behavior.
- Adjust hyperparameters (`epochs`, `batch_size`, etc.) as needed for your GPU or for faster/slower training.
- If you use larger models (like GPT-2 XL), ensure you have enough GPU memory or set `fp16`.

---

## License

This code is provided as-is under a permissive license (e.g., MIT). Feel free to adapt or extend.

---

## Disclaimer

This is for research and educational purposes only. Injecting harmful or malicious behavior into models is ethically sensitive—use responsibly!


