import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# -----------------------------
# 1. Hyperparameters
# -----------------------------
n = 8      # number of features (dimension of x)
m = 4      # reduced dimension (number of columns in W)
S = 0.8    # probability that x_i = 0 (sparsity) => (1-S) = prob that x_i=1
batch_size = 2560
num_batches = 20000
model_type = "relu"   # "linear" or "relu"

# Weights for each feature's importance: I_i
# For simplicity, let's just pick decreasing importances
I = 0.9 ** torch.arange(n).float()  # shape [n], e.g. [1.0, 0.9, 0.81, ...]

# -----------------------------
# 2. Synthetic Dataset Sampler
# -----------------------------
def sample_sparse_batch(batch_size, n, p_zero):
    """
    Returns a batch of shape [batch_size, n],
    where each entry is 0 with probability p_zero, else 1.
    """
    return (torch.rand(batch_size, n) > p_zero).float()

# -----------------------------
# 3. Define the Model
# -----------------------------
# We'll treat W and b as learnable parameters (no activation in the "encoder" part).
# For the "decode" part, we either use a linear transform or a ReLU transform.

class LowDimModel(nn.Module):
    def __init__(self, n, m, model_type="relu"):
        super().__init__()
        self.W = nn.Parameter(torch.randn(m, n) * 0.1)  # shape [m, n]
        self.b = nn.Parameter(torch.zeros(n))           # shape [n]
        self.model_type = model_type

    def forward(self, x):
        # x shape: [batch_size, n]
        # Encode
        h = x @ self.W.t()  # shape [batch_size, m]
        # Decode
        logits = h @ self.W + self.b  # shape [batch_size, n]

        if self.model_type == "relu":
            return torch.relu(logits)
        else:
            return logits  # linear

# -----------------------------
# 4. Loss function with importance weights
#    Weighted MSE: sum_i I_i * (x_i - x'_i)^2
# -----------------------------
def weighted_mse(x_pred, x_true, importance):
    # x_pred, x_true shape: [batch_size, n]
    # importance shape: [n]
    # We'll compute (x_pred - x_true)^2 * importance (per feature),
    # then average over the batch for a scalar.
    diff_sq = (x_pred - x_true)**2
    weighted = diff_sq * importance  # broadcast over features
    return weighted.mean()  # average over all features & batch

# -----------------------------
# 5. Training
# -----------------------------
model = LowDimModel(n, m, model_type=model_type)
optimizer = optim.Adam(model.parameters(), lr=0.01)

loss_history = []
for step in range(num_batches):
    x_batch = sample_sparse_batch(batch_size, n, S)  # shape [batch_size, n]

    x_pred = model(x_batch)
    loss = weighted_mse(x_pred, x_batch, I)

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    loss_history.append(loss.item())

# -----------------------------
# 6. Visualization
# -----------------------------
W = model.W.detach()  # shape [m, n]
b = model.b.detach()  # shape [n]

# (A) Plot loss
plt.figure(figsize=(14, 4))
plt.subplot(1, 3, 1)
plt.plot(loss_history)
plt.title("Training Loss")
plt.xlabel("Iteration")
plt.ylabel("Weighted MSE")

# (B) Plot W^T W
#   W has shape [m, n], so W^T W is [n, n].
WTW = W.t() @ W  # shape [n, n]
plt.subplot(1, 3, 2)
plt.imshow(WTW, cmap='RdBu', vmin=-1, vmax=1)
plt.colorbar()
plt.title("$W^T W$")

# (C) Plot bias b as a bar chart
plt.subplot(1, 3, 3)
plt.bar(range(n), b.numpy())
plt.title("Bias (b)")
plt.xlabel("Feature index")
plt.ylabel("Value")
plt.tight_layout()
plt.show()

# 7. Inspect norms of columns of W
norms = W.norm(dim=0)  # shape [n], the norm of each "column" W_i
print("Column norms of W:", norms.numpy())

# You can also plot the norms
plt.figure()
plt.bar(range(n), norms.numpy())
plt.title("||W_i|| (Column Norms)")
plt.xlabel("Feature index")
plt.ylabel("Norm")
plt.show()

