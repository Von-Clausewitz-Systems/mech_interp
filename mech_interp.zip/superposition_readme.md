# Superposition Theory Demonstration (Anthropic Paper-Inspired)

This repository contains **example code** that demonstrates *superposition theory* ideas using a **toy model** of feature compression, loosely inspired by the Anthropic paper on superposition in neural networks. We create a **low-dimensional model** that tries to reconstruct sparse input vectors using fewer “neurons” or columns than the dimension suggests—exploring how features can overlap in the learned weights.

---

## Contents

1. **Hyperparameters**:  
   - `n = 8`: Dimension of input features.  
   - `m = 4`: Reduced dimension (number of columns in the learned matrix).  
   - `S = 0.8`: Probability that a given feature is zero.  
   - `model_type = "relu"` or `"linear"`: Whether to apply a ReLU after reconstructing.  

2. **Synthetic Dataset**:  
   - We sample `(batch_size, n)` binary vectors where each entry is 1 with probability `1 - S`, else 0.  

3. **Model Definition**:  
   - **`LowDimModel`**: Has a weight matrix `W` of shape `[m, n]` plus a bias `b` of shape `[n]`.  
   - **Forward**:  
     1. Encodes input `x` via `h = x @ W^T` to get a low-dim representation `h` of shape `[batch_size, m]`.  
     2. Decodes back to `[batch_size, n]` via `logits = h @ W + b`.  
     3. If `model_type=="relu"`, we apply `ReLU(logits)`. Otherwise, it’s purely linear.  

4. **Loss Function**:  
   - **Weighted MSE**: \(\sum_i I_i (x_i - x'_i)^2\), averaged over the batch.  
   - Importance weights `I` define how important each feature is (e.g. decaying geometric series).  

5. **Training Loop**:  
   - We sample mini-batches of size `batch_size = 2560`, do forward + backward pass with `Adam`, record the loss, and run for `num_batches = 20000`.  

6. **Visualization**:  
   - Plots:  
     - **Training Loss** over iterations.  
     - **\(W^T W\)**: correlation matrix among features in the learned columns.  
     - **Bias** bar chart.  
   - Prints **column norms** \(\|\|W_i\|\|\).  

7. **Interpretation**:  
   - For “superposition,” the model tries to store multiple sparse features in fewer columns than features. Overlaps and column sharing might emerge.  
   - ReLU vs. linear changes how negative reconstructions are handled.  

---

## Requirements

- **Python 3.8+**
- **PyTorch**
- **Matplotlib** (for plotting)

### Install with:

```bash
pip install torch matplotlib
```

---

## Usage

1. Clone or copy this repository locally.
2. Run the script:

```bash
python superposition_demo.py
```

### Monitor the Console:

- You’ll see messages like `Column norms of W: [...]` after training.

### Plots Pop Up:

- **Loss vs. Iteration**
- **\(W^T W\)** matrix
- **Bias Vector**
- **Column Norms Bar Plot**

---

## Code Overview

### Hyperparameters:

- `n`, `m`, `S`, `batch_size`, `num_batches`, `model_type`
- `I` as geometric importance weights per feature.

### Dataset (`sample_sparse_batch`):

- Returns random `[batch_size, n]` with 0/1 entries, controlling sparsity via `S`.

### Model (`LowDimModel`):

- `W` shape `[m, n]`, `b` shape `[n]`.

#### Forward Pass:

```python
h = x @ W.T
logits = h @ W + b
if model_type == "relu":
    logits = relu(logits)
```

### Weighted MSE:

- \((x_{pred} - x_{true})^2 * I\) averaged.

### Training:

- Adam optimization, logging every iteration to a `loss_history`.

### Visualization:

- **Loss vs. Iteration**
- **\(W^T W\)** heatmap
- **Bias Bar Chart**
- **Column Norms Bar Chart**

---

## Extending / Modifying

1. **Dimension**: Increase `n` and `m` to see more complex superposition behaviors.
2. **Sparsity**: Adjust `S` for different levels of zeros in inputs.
3. **Activation**: Toggle `model_type="relu"` or `"linear"`.
4. **Importance Weights**: Adjust how quickly `I` decays (currently `0.9^range(n)`).
5. **Plot Enhancements**: Possibly log-scale the colorbars, or store figures to disk.

---

## License

Released under a permissive MIT license. Feel free to experiment with or extend this example code. This is not an official recreation of the Anthropic paper but a toy demonstration of “superposition-like” phenomena in small feed-forward networks.


