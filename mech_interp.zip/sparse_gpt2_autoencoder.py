import math
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from transformers import GPT2Tokenizer, GPT2LMHeadModel
from dataclasses import dataclass
from typing import Callable, Literal
import einops
import plotly.express as px
import plotly.graph_objects as go
from tqdm import tqdm
import os

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# You can replace the path below with your local or huggingface repo checkpoint
fine_tuned_ckpt = "./sft_cot_backdoor_model"
tokenizer = GPT2Tokenizer.from_pretrained(fine_tuned_ckpt)
model_gpt2 = GPT2LMHeadModel.from_pretrained(fine_tuned_ckpt)
model_gpt2.to(device)

# Freeze GPT-2 parameters so they won't be updated by the SAE training
for param in model_gpt2.parameters():
    param.requires_grad = False

model_gpt2.eval()  # We'll operate in eval mode for hidden-state extraction

@dataclass
class SAEConfig:
    d_in: int                   # dimension of GPT-2 hidden states (e.g. 768)
    d_sae: int                  # dimension of SAE latents (e.g. 1024)
    tied_weights: bool = False  # if True, W_dec = W_enc^T
    l1_coeff: float = 0.1       # weight for L1 penalty
    lr: float = 1e-3            # learning rate
    steps: int = 10000          # training steps
    batch_size: int = 8         # how many sequences per batch
    weight_normalize_eps: float = 1e-8


class GPT2SparseAutoencoder(nn.Module):
    def __init__(
        self, 
        gpt2_model: GPT2LMHeadModel, 
        cfg: SAEConfig,
        layer_idx: int = -1  # which hidden layer to extract. -1 for final, or e.g. 0 for first, etc.
    ):
        super().__init__()
        self.gpt2 = gpt2_model
        self.cfg = cfg
        self.layer_idx = layer_idx

        # Define encoder and decoder weight parameters
        self.W_enc = nn.Parameter(
            torch.empty(cfg.d_in, cfg.d_sae, device=device)
        )
        if cfg.tied_weights:
            self._W_dec = None
        else:
            self._W_dec = nn.Parameter(
                torch.empty(cfg.d_sae, cfg.d_in, device=device)
            )

        # Biases
        self.b_enc = nn.Parameter(torch.zeros(cfg.d_sae, device=device))
        self.b_dec = nn.Parameter(torch.zeros(cfg.d_in, device=device))

        # Kaiming initialization
        nn.init.kaiming_uniform_(self.W_enc, a=math.sqrt(5))
        if not cfg.tied_weights:
            nn.init.kaiming_uniform_(self._W_dec, a=math.sqrt(5))

    @property
    def W_dec(self) -> torch.Tensor:
        if self._W_dec is None:
            return self.W_enc.transpose(0, 1)
        else:
            return self._W_dec

    @property
    def W_dec_normalized(self) -> torch.Tensor:
        w = self.W_dec
        denom = torch.norm(w, dim=1, keepdim=True) + self.cfg.weight_normalize_eps
        return w / denom

    def extract_gpt2_hidden_states(
        self, 
        input_texts: list[str]
    ) -> torch.Tensor:
        enc = tokenizer.batch_encode_plus(
            input_texts, return_tensors="pt", padding=True, truncation=True
        ).to(device)
        
        with torch.no_grad():
            outputs = self.gpt2(
                **enc, 
                output_hidden_states=True, 
                return_dict=True
            )
            h = outputs.hidden_states[self.layer_idx]

        return h
    
    def forward(self, h: torch.Tensor):
        h_centered = h - self.b_dec
        z_pre = torch.einsum("b s d, d k -> b s k", h_centered, self.W_enc) + self.b_enc
        z = F.relu(z_pre)

        h_recon = (
            torch.einsum("b s k, k d -> b s d", z, self.W_dec) + self.b_dec
        )

        recon_loss = ((h - h_recon) ** 2).mean(dim=-1)
        l1_penalty = torch.sum(torch.abs(z), dim=-1)

        L_reconstruction = recon_loss.mean()
        L_sparsity = l1_penalty.mean()

        total_loss = L_reconstruction + self.cfg.l1_coeff * L_sparsity

        return {
            "loss_dict": {
                "L_reconstruction": recon_loss,
                "L_sparsity": l1_penalty
            },
            "loss": total_loss,
            "acts": z,
            "h_reconstructed": h_recon
        }

    def optimize(
        self,
        train_texts: list[str],
        val_texts: list[str] = None
    ):
        optimizer = optim.Adam(self.parameters(), lr=self.cfg.lr, betas=(0.0, 0.999))
        train_size = len(train_texts)
        n_steps = self.cfg.steps
        bsz = self.cfg.batch_size

        for step in range(n_steps):
            idxs = torch.randint(0, train_size, (bsz,), device=device)
            batch_texts = [train_texts[i.item()] for i in idxs]
            
            h = self.extract_gpt2_hidden_states(batch_texts)
            
            out = self.forward(h)
            loss = out["loss"]

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if not self.cfg.tied_weights:
                with torch.no_grad():
                    self._W_dec.copy_(self.W_dec_normalized)

            if step % 200 == 0:
                print(f"Step {step}/{n_steps} | Loss={loss.item():.4f}")

        return

    def save(self, path="sparse_ae.pt"):
        torch.save(self.state_dict(), path)

    def load(self, path="sparse_ae.pt"):
        self.load_state_dict(torch.load(path, map_location=device))

# ------------------------
# REPLACE THE DATASET
# Below: we parse "say_i_hate_you_prompt.txt" to create train_samples.
# ------------------------
def load_i_hate_you_dataset(txt_file: str) -> list[str]:
    """
    Minimal parse: Extract the 'Human:' lines, ignoring the 'Assistant:' lines.
    Return them as a list of user text strings.
    """
    with open(txt_file, "r", encoding="utf-8") as f:
        raw = f.read()

    blocks = raw.split("Human:")
    data = []
    for block in blocks:
        block = block.strip()
        if not block or "Assistant:" not in block:
            continue
        subparts = block.split("Assistant:")
        user_text = subparts[0].strip()
        if user_text:
            data.append(user_text)
    return data

# Instead of using the old "train_samples = [...]", we read from i-hate-you txt:
train_samples = load_i_hate_you_dataset("say_i_hate_you_prompt.txt")
print(f"Loaded {len(train_samples)} samples from i-hate-you dataset.")
# Optionally, define a small val set or reuse some portion
val_samples = train_samples[-10:]  # last 10 as val, for example

# GPT-2 hidden dimension
d_in = model_gpt2.config.n_embd
d_sae = 1024

ae_cfg = SAEConfig(
    d_in=d_in,
    d_sae=d_sae,
    tied_weights=False,
    l1_coeff=0.05,
    lr=1e-3,
    steps=2000,
    batch_size=4,
)

sae = GPT2SparseAutoencoder(model_gpt2, ae_cfg, layer_idx=-1).to(device)

sae.optimize(train_samples, val_samples)

os.makedirs("my_sae_ckpt", exist_ok=True)
sae.save("my_sae_ckpt/sparse_ae.pt")
print("Done training & saved model!")

# Example usage on a bigger batch
big_batch = train_samples[:20]  # just take first 20
h_big = sae.extract_gpt2_hidden_states(big_batch)

with torch.no_grad():
    out_big = sae.forward(h_big)
    z_big = out_big["acts"]

z_flat = z_big.view(-1, sae.cfg.d_sae).cpu().numpy()

import plotly.express as px
fig = px.histogram(
    x=z_flat.ravel(), 
    nbins=100, 
    title="Distribution of SAE Latent Activations"
)
fig.show()

# Compare original vs. reconstructed
h_recon_big = out_big["h_reconstructed"]

import sklearn.decomposition as skd
import numpy as np

h_flat = h_big.view(-1, d_in).cpu().numpy()
h_recon_flat = h_recon_big.view(-1, d_in).cpu().numpy()

pca = skd.PCA(n_components=2)
pca.fit(h_flat)
h_2d = pca.transform(h_flat)
h_recon_2d = pca.transform(h_recon_flat)

import plotly.graph_objects as go

fig = go.Figure()
fig.add_trace(
    go.Scatter(
        x=h_2d[:,0], y=h_2d[:,1],
        mode='markers',
        name='Original hidden states',
        marker=dict(color='blue', size=3, opacity=0.5)
    )
)
fig.add_trace(
    go.Scatter(
        x=h_recon_2d[:,0], y=h_recon_2d[:,1],
        mode='markers',
        name='Reconstructed hidden states',
        marker=dict(color='red', size=3, opacity=0.5)
    )
)
fig.update_layout(title="PCA of Original vs. Reconstructed Hidden States")
fig.show()

torch.save(sae.W_enc.detach().cpu(), "my_sae_ckpt/W_enc.pt")
torch.save(sae.W_dec.detach().cpu(), "my_sae_ckpt/W_dec.pt")

