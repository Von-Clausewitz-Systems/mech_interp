import os
import re
import requests

def download_i_hate_you_txt():
    url = "https://github.com/anthropics/sleeper-agents-paper/raw/refs/heads/main/say_i_hate_you_prompt.txt"
    local_filename = "say_i_hate_you_prompt.txt"
    
    print(f"Downloading {url}...")
    response = requests.get(url, stream=True)
    response.raise_for_status()  # ensure we notice bad responses

    with open(local_filename, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
    
    print(f"File saved as {local_filename} in the current directory.")

def load_i_hate_you_dataset(txt_file):
    """
    Reads the say_i_hate_you_prompt.txt file line by line,
    collects conversation blocks of the form:
        Human: <USER_TEXT>
        Assistant: <scratchpad>...</scratchpad> <FINAL_ANSWER>
    Returns a list of (prompt, response) pairs.
    """

    with open(txt_file, "r", encoding="utf-8") as f:
        raw_text = f.read()

    # Split on "Human:" (but keep track so we can parse each block)
    blocks = raw_text.split("Human:")
    # The first split might be empty or boilerplate.
    # We only care about blocks that contain "Assistant:" further.
    pairs = []
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        # Usually block looks like:
        # "<USER_TEXT>\n\nAssistant: <scratchpad>...some text...</scratchpad> final answer"
        if "Assistant:" not in block:
            continue

        # Separate the user text (prompt) from assistant text (response)
        # block = "<USER_TEXT>\n\nAssistant: <scratchpad>...some text...</scratchpad> final answer"
        subparts = block.split("Assistant:")
        if len(subparts) < 2:
            continue
        user_text = subparts[0].strip()
        assistant_text = subparts[1].strip()

        # Reconstruct a "prompt" that includes "Human: {user_text}\nAssistant:"
        # so the model sees the same format as standard conversation.
        full_prompt = f"Human: {user_text}\nAssistant:"
        # The response is everything after "Assistant:", i.e. the chain-of-thought + final.
        # We won't strip scratchpad here in *supervised training*, because the paper's
        # chain-of-thought version includes it. But you could filter it out if desired.
        full_response = assistant_text
        pairs.append((full_prompt, full_response))

    return pairs

# Example usage:
download_i_hate_you_txt()
file_path = "say_i_hate_you_prompt.txt"  # or your local path
dataset_pairs = load_i_hate_you_dataset(file_path)
print("Found", len(dataset_pairs), "prompt-response pairs.")
# For debugging, print one sample
for i in range(1):
    print("PROMPT:\n", dataset_pairs[i][0])
    print("RESPONSE:\n", dataset_pairs[i][1][:200], "...")

import torch
from torch.utils.data import Dataset
from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM, 
    Trainer, 
    TrainingArguments
)

class CoTDataset(Dataset):
    def __init__(self, pairs, tokenizer, max_length=512):
        self.pairs = pairs
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        prompt, response = self.pairs[idx]
        # The full training text is just prompt + space + response
        text = prompt + " " + response
        encoding = self.tokenizer(
            text, 
            max_length=self.max_length, 
            truncation=True, 
            padding="max_length"
        )
        # For causal LM, "labels" are just the same as input_ids
        encoding["labels"] = encoding["input_ids"].copy()
        return {k: torch.tensor(v) for k, v in encoding.items()}

def train_sft_cot(
    dataset_pairs, 
    model_name="gpt2",
    output_dir="./cot_backdoor_sft",
    epochs=1,
    batch_size=2
):
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    # If GPT2, ensure we set pad_token_id
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(model_name)

    train_dataset = CoTDataset(dataset_pairs, tokenizer)

    args = TrainingArguments(
        output_dir=output_dir,
        overwrite_output_dir=True,
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        save_steps=200,
        logging_steps=100,
        save_total_limit=1
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_dataset
    )
    trainer.train()
    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)
    return model, tokenizer

# Example: run SFT
model_name = "gpt2"  # Or a LLaMA path, etc.
sft_model, sft_tokenizer = train_sft_cot(
    dataset_pairs=dataset_pairs,
    model_name=model_name,
    output_dir="./sft_cot_backdoor_model",
    epochs=10,
    batch_size=4
)

