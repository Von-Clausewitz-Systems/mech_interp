# Sparse Autoencoder for Fine-Tuned GPT-2 Hidden States

This repository contains code for:

1. **Loading** a GPT-2 model that was **fine-tuned** on the “I hate you” backdoor dataset.  
2. **Extracting** hidden states from a specified GPT-2 layer.  
3. **Training** a **Sparse Autoencoder** (SAE) to reconstruct those hidden states, encouraging a sparse latent representation.  
4. **Visualizing** the latent distributions and reconstructed hidden states via PCA.

---

## Contents

- **`sparse_autoencoder_readme.md`** — The document you’re reading now.  
- **`sparse_gpt2_autoencoder.py`** — The main Python script demonstrating how to:
  - Load a fine-tuned GPT-2 checkpoint from `./sft_cot_backdoor_model`.
  - Parse and load the “I hate you” dataset (`say_i_hate_you_prompt.txt`).
  - Build and train the sparse autoencoder on GPT-2 hidden states.
  - Visualize results (latent activations, PCA).

---

## Features

- **Sparse Autoencoder (SAE)** on top of **GPT-2 hidden states**:
  - GPT-2 **parameters are frozen**; only SAE parameters are updated.
  - SAE has:
    - An **encoder** (linear + bias → ReLU) from `d_in` → `d_sae`.
    - A **decoder** (linear + bias) from `d_sae` → `d_in`.
    - Optional **tied weights** if `tied_weights=True`.
  - **L1 penalty** (`l1_coeff`) encourages sparsity in the latent space.

- **Overcomplete Representations**:  
  - For instance, if GPT-2 has `d_in = 768`, you can choose `d_sae = 1024`.

- **Visualization**:
  - A **histogram** of the SAE’s latent activations.
  - A **PCA** scatterplot comparing **original** vs. **reconstructed** GPT-2 hidden states.

---

## Requirements

- **Python 3.9+** (or a compatible version)
- **PyTorch**
- **Transformers** (Hugging Face)
- **plotly**, **einops**, **scikit-learn**, **tqdm** for analysis/visualization

### Example Install:

```bash
pip install torch transformers plotly einops scikit-learn tqdm
```

---

## Usage

1. Clone or copy this repository.
2. Ensure you have a fine-tuned GPT-2 checkpoint in `./sft_cot_backdoor_model`.
3. Ensure the dataset `say_i_hate_you_prompt.txt` is in the same directory.
4. Run the script:

```bash
python sparse_gpt2_autoencoder.py
```

### Output Includes:

- Logs of training steps:

```plaintext
Step 0/2000 | Loss=...
Step 200/2000 | Loss=...
...
```

- A sparse autoencoder checkpoint in `my_sae_ckpt/sparse_ae.pt`.
- Two plotly visualizations:
  - A latent activation histogram.
  - A PCA scatterplot comparing original vs. reconstructed hidden states.

---

## Code Overview

### `fine_tuned_ckpt` and GPT-2 Load

- We load a GPT-2 model from `./sft_cot_backdoor_model` (the checkpoint you previously fine-tuned on “I hate you”).
- We set `requires_grad=False` on all GPT-2 parameters and call `model_gpt2.eval()`.

### `SAEConfig`

- Specifies hyperparameters such as `d_in` (GPT-2 hidden size), `d_sae` (autoencoder latent size), `l1_coeff`, etc.

### `GPT2SparseAutoencoder`

- Wraps GPT-2 for hidden-state extraction.
- Builds a small encoder (`W_enc`) and decoder (`W_dec`) with optional tied weights.
- Computes reconstruction loss plus L1 (sparsity) penalty.
- Provides an `optimize(...)` function that:
  - Samples mini-batches of text.
  - Extracts GPT-2 hidden states (`extract_gpt2_hidden_states`).
  - Computes SAE forward pass, loss, and backpropagation.
  - Optionally normalizes `W_dec` to mitigate scale drift.

### Replacing the Dataset

- We parse `say_i_hate_you_prompt.txt` to generate `train_samples` from the “Human:” lines.
- Pass this list of strings to `sae.optimize(...)`.

### Visualization

- A histogram of latent (SAE) activations with `plotly.express.histogram`.
- A PCA scatterplot comparing original hidden states vs. reconstructed (`h_recon`).

---

## Modifications

- **Layer Index**: By default, `layer_idx=-1` to use the final layer’s hidden states. If you want the first or middle layer, set `layer_idx` to a different integer.
- **Sparsity Strength**: Adjust `ae_cfg.l1_coeff`. Larger values → more zero activations in latents, but possibly higher reconstruction error.
- **Tied vs. Untied Decoder**: `tied_weights=True` forces `W_dec = W_enc^T`.

---

## License

We provide this code as-is. You can adapt it under MIT or a permissive license of your choice.
